package com.company;

import java.util.ArrayList;

public class Preklad
{
    ArrayList<String> slovenskeslovo = new ArrayList<String>();
    ArrayList<String> anglickeslovo = new ArrayList<String>();
    String[] origoSlovenskeslovo = {"ahoj", "ako", "áno", "Boh" , "beh", "čurák", "byť","prečo", "kde", "kedy", "kam","láska", "sviňa"};
    String[] origoAnglickeslovo = {"hello", "how" , "yes" , "God" , "run", "dick", "to be", "why" ,"where","when","whereto","love","saw"};
    {
        for (int i = 0; i < origoSlovenskeslovo.length; i++)
        {
            slovenskeslovo.add(origoSlovenskeslovo[i]);
            anglickeslovo.add(origoAnglickeslovo[i]);
        }

    }
    public void sk_en(String sk)
    {
        for (int i=0; i< slovenskeslovo.size(); i++)
        {
            if (sk.equals(slovenskeslovo.get(i)))
            {
                System.out.println(anglickeslovo.get(i));
            }
        }

    }
    public void en_sk(String en)
    {
        for (int i=0; i< anglickeslovo.size(); i++)
        {
            if (en.equals(anglickeslovo.get(i)))
            {
                System.out.println(slovenskeslovo.get(i));
            }
        }
    }
    public void pridavanie (String slovo, ArrayList<String> list)
    {
        list.add(slovo);

    }
    public void odobratie (String slovo, ArrayList<String> list)
    {
        list.remove(slovo);
    }
}
