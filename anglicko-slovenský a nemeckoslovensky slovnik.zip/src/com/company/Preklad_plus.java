package com.company;

import java.util.ArrayList;

public class Preklad_plus
{
    ArrayList<String> slovenskeslovo = new ArrayList<String>();
    ArrayList<String> nemeckeslovo = new ArrayList<String>();
    String[] origoSlovenskeslovo = {"ahoj", "ako", "áno", "Boh" , "beh", "čurák", "byť","prečo", "kde", "kedy", "kam","láska", "sviňa"};
    String[] origoNemeckeslovo = {"hallo", "wie" , "ja" , "God" , "laufen","schwanz", "sein","warum","wo","wann","wohin","liebe","schwein"};
    {
        for (int i = 0; i < origoSlovenskeslovo.length; i++) {
            slovenskeslovo.add(origoSlovenskeslovo[i]);
            nemeckeslovo.add(origoNemeckeslovo[i]);
        }

    }
    public void sk_de(String sk)
    {
        for (int i=0; i< slovenskeslovo.size(); i++)
        {
            if (sk.equals(slovenskeslovo.get(i)))
            {
                System.out.println(nemeckeslovo.get(i));
            }
        }

    }
    public void de_sk(String de)
    {
        for (int i=0; i< nemeckeslovo.size(); i++)
        {
            if (de.equals(nemeckeslovo.get(i)))
            {
                System.out.println(slovenskeslovo.get(i));
            }
        }
    }
    public void pridavanie_plus (String slovo, ArrayList<String> list)
    {
        list.add(slovo);

    }
    public void odobratie_plus (String slovo, ArrayList<String> list)
    {
        list.remove(slovo);
    }

}

