package com.company;


import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        Preklad preklad = new Preklad();
        Preklad_plus preklad_plus = new Preklad_plus();
        Scanner scanner = new Scanner(System.in, "Windows-1250");
        char pokracovat = 'a';
        while (pokracovat == 'a')
        {
            System.out.println("Vyber si typ slovníka:");
            System.out.println("99) pre en_sk slovník");
            System.out.println("100) pre de_sk slovník");
            int slovnik = scanner.nextInt();
            if (slovnik == 99)
            {

                System.out.println("Vitajte v mojom uzasnom slovniku");
                System.out.println("Teraz si vyber moznost:");
                System.out.println("1) Výpis celého slovníka podľa výberu");
                System.out.println("2) Preklad z angličtiny do slovenčiny ");
                System.out.println("3) Preklad zo slovenčiny do angličtiny ");
                System.out.println("4) Pridanie nového slova a následný výpis slovníka");
                System.out.println("5) Zmazanie slova a následný výpis slovníka");
                int moznost = scanner.nextInt();
                if (moznost == 1)
                {
                    System.out.println("6) Výpis slovenskej časti: ");
                    System.out.println("7) Výpis anglickej časti: ");
                    System.out.println("8) Celého slovníka: ");
                    int vyber = scanner.nextInt();
                    if (vyber == 6)
                    {
                        System.out.println(preklad.slovenskeslovo);
                    }
                    else if (vyber == 7)
                    {
                        System.out.println(preklad.anglickeslovo);
                    }
                    else if (vyber == 8)
                    {
                        System.out.println(preklad.slovenskeslovo);
                        System.out.println("---------------------------------------------------------------------------------");
                        System.out.println(preklad.anglickeslovo);
                    }

                }
                else if (moznost == 2)
                {
                    System.out.println("Zadaj anglicke slovo:");
                    String slovo = scanner.next();
                    preklad.en_sk(slovo);
                }
                else if (moznost == 3)
                {
                    System.out.println("Zadaj slovenske slovo:");
                    String slovo = scanner.next();
                    preklad.sk_en(slovo);
                }
                else if (moznost == 4)
                {
                    System.out.println("zadaj slovo po slovensky");
                    String slovo = scanner.next();
                    preklad.pridavanie(slovo, preklad.slovenskeslovo);
                    System.out.println("zadaj slovo po anglicky");
                    slovo = scanner.next();
                    preklad.pridavanie(slovo, preklad.anglickeslovo);
                    System.out.println("Pridane slovo v slovencine v poli slov:");
                    System.out.println(preklad.slovenskeslovo);
                    System.out.println("---------------------------------------------------------------------------------");
                    System.out.println("Pridane slovo v anglictine v poli slov:");
                    System.out.println(preklad.anglickeslovo);

                } else if (moznost == 5)
                {
                    System.out.println("zadaj zo slovníka slovo na odobratie");
                    String slovo = scanner.next();
                    preklad.odobratie(slovo, preklad.slovenskeslovo);
                    System.out.println(preklad.slovenskeslovo);
                }
            }
            else if (slovnik == 100)
            {
                System.out.println("Vitajte v mojom uzasnom slovniku");
                System.out.println("Teraz si vyber moznost:");
                System.out.println("1) Výpis celého slovníka podľa výberu");
                System.out.println("2) Preklad z nemčiny do slovenčiny ");
                System.out.println("3) Preklad zo slovenčiny do nemčiny ");
                System.out.println("4) Pridanie nového slova a následný výpis slovníka");
                System.out.println("5) Zmazanie slova a následný výpis slovníka");
                int moznost2 = scanner.nextInt();
                if (moznost2 == 1)
                {
                    System.out.println("6) Výpis slovenskej časti: ");
                    System.out.println("7) Výpis nemeckej časti: ");
                    System.out.println("8) Celého slovníka: ");
                    int vyber2 = scanner.nextInt();
                    if (vyber2 == 6)
                    {
                        System.out.println(preklad_plus.slovenskeslovo);
                    }
                    else if (vyber2 == 7) {
                        System.out.println(preklad_plus.nemeckeslovo);
                    }
                    else if (vyber2 == 8)
                    {
                        System.out.println(preklad_plus.slovenskeslovo);
                        System.out.println("---------------------------------------------------------------------------------");
                        System.out.println(preklad_plus.nemeckeslovo);
                    }

                }
                else if (moznost2 == 2)
                {
                    System.out.println("Zadaj nemecké slovo:");
                    String slovo = scanner.next();
                    preklad_plus.de_sk(slovo);
                }
                else if (moznost2 == 3)
                {
                    System.out.println("Zadaj slovenské slovo:");
                    String slovo = scanner.next();
                    preklad_plus.sk_de(slovo);
                }
                else if (moznost2 == 4)
                {
                    System.out.println("zadaj slovo po slovensky");
                    String slovo = scanner.next();
                    preklad_plus.pridavanie_plus(slovo, preklad_plus.slovenskeslovo);
                    System.out.println("zadaj slovo po nemecky");
                    slovo = scanner.next();
                    preklad_plus.pridavanie_plus(slovo, preklad_plus.nemeckeslovo);
                    System.out.println("Pridane slovo v slovencine v poli slov:");
                    System.out.println(preklad_plus.slovenskeslovo);
                    System.out.println("---------------------------------------------------------------------------------");
                    System.out.println("Pridane slovo v nemčine v poli slov:");
                    System.out.println(preklad_plus.nemeckeslovo);

                }
                else if (moznost2 == 5)
                {
                    System.out.println("zadaj zo slovníka slovo na odobratie");
                    String slovo = scanner.next();
                    preklad_plus.odobratie_plus(slovo, preklad_plus.slovenskeslovo);
                    System.out.println(preklad_plus.slovenskeslovo);
                }

            }
            System.out.println("chces pokracovat?[ano-a/nie-b]");
            char b = scanner.next().charAt(0);
            if( b != 'a')
            {
                System.out.println("Som zvedavý ako sa ti bude šprechovať v zahraničí ty žebrák :D");
                break;
            }
        }


    }
}



